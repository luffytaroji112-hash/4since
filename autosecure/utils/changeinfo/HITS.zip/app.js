const axios = require('axios');
const { createCanvas, loadImage } = require('canvas');
const StackBlur = require('stackblur-canvas');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const HYPIXEL_API_KEY = "";

async function getUUID(username) {
  const res = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${username}`);
  return res.data.id;
}

function calcNetworkLevel(exp) {
  return exp ? Math.round(((2 * exp + 30625) ** 0.5 / 50) - 2.5) : 0;
}

function getRank(player) {
  if (player.rank && player.rank !== 'NORMAL') return player.rank;
  if (player.monthlyPackageRank && player.monthlyPackageRank !== 'NONE') return 'MVP++';
  if (player.newPackageRank) {
    switch (player.newPackageRank) {
      case 'MVP_PLUS': return 'MVP+';
      case 'MVP': return 'MVP';
      case 'VIP_PLUS': return 'VIP+';
      case 'VIP': return 'VIP';
    }
  }
  return 'Non';
}

async function fetchHypixelStats(username) {
  try {
    const uuid = await getUUID(username);
    const { data } = await axios.get(
      `https://api.hypixel.net/player?key=${HYPIXEL_API_KEY}&uuid=${uuid}`
    );
    if (!data.success || !data.player) throw new Error('Cannot Find Player');
    const p = data.player;

    const bedwarsStars = p.achievements?.bedwars_level || 0;
    const networkLevel = calcNetworkLevel(p.networkExp);
    const duels = p.stats?.Duels || {};
    const duelKills = duels.kills || 0;
    const duelDeaths = duels.deaths || 1;
    const duelKDR = (duelKills / duelDeaths).toFixed(2);
    const plusColor = p.rankPlusColor || p.monthlyRankColor || 'None';
    const gifted = p.ranksGifted || 0;
    const sbLevel = p.achievements?.skyblock_harvester || 0;
    const networth = 0;
    const rank = getRank(p);

    return {
      Rank: rank,
      Networth: networth,
      'SB Level': sbLevel,
      'Bedwars Stars': bedwarsStars,
      'Network Level': networkLevel,
      'Duel KDR': duelKDR,
      'Plus Colour': plusColor,
      Gifted: gifted,
    };
  } catch (err) {
    console.error('Error:', err.message);
    return null;
  }
}

function maskUsername(username) {
  return '*'.repeat(username.length);
}

async function createStatsCard({ username, stats, wallpaperDir = './wallpapers' }) {
  const skinURL = `https://vzge.me/full/384/${username}`;
  const width = 700, height = 420;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  const files = fs.readdirSync(wallpaperDir).filter(f => /\.(png|jpe?g)$/i.test(f));
  if (!files.length) throw new Error('Cannot Find Wallpaper');
  const randomFile = files[Math.floor(Math.random() * files.length)];
  const wallpaper = await loadImage(path.join(wallpaperDir, randomFile));

  const scale = Math.max(width / wallpaper.width, height / wallpaper.height);
  const cropW = width / scale;
  const cropH = height / scale;
  const cropX = (wallpaper.width - cropW) / 2;
  const cropY = (wallpaper.height - cropH) / 2;
  ctx.drawImage(wallpaper, cropX, cropY, cropW, cropH, 0, 0, width, height);

  const imgData = ctx.getImageData(0, 0, width, height);
  StackBlur.imageDataRGBA(imgData, 0, 0, width, height, 25);
  ctx.putImageData(imgData, 0, 0);

  try {
    const skin = await loadImage(skinURL);
    const displayWidth = 160;
    const displayHeight = displayWidth * (skin.height / skin.width);
    const x = 60, y = 110;
    ctx.fillStyle = 'rgba(27,27,27,0.55)';
    drawRoundedRect(ctx, x - 20, y - 30, displayWidth + 40, displayHeight + 60, 40);
    ctx.fill();
    ctx.drawImage(skin, x, y, displayWidth, displayHeight);
  } catch {
    ctx.fillStyle = '#555';
    ctx.fillRect(60, 140, 160, 160);
  }

  const masked = maskUsername(username);
  ctx.font = '28px Arial';
  const fixedBoxW = 400;
  const fixedBoxH = 50;
  const boxX = width / 2 - fixedBoxW / 2;
  const boxY = 20;
  ctx.fillStyle = 'rgba(20,20,20,0.55)';
  drawRoundedRect(ctx, boxX, boxY, fixedBoxW, fixedBoxH, 12);
  ctx.fill();
  ctx.fillStyle = '#fff';
  const textW = ctx.measureText(masked).width;
  ctx.fillText(masked, boxX + (fixedBoxW - textW) / 2, boxY + 34);

  const entries = [
    { key: 'Networth', color: '#ff9900' },
    { key: 'SB Level', color: '#66ccff' },
    { key: 'Bedwars Stars', color: '#00ff66' },
    { key: 'Network Level', color: '#cc66ff' },
    { key: 'Duel KDR', color: '#6699ff' },
    { key: 'Plus Colour', color: '#ffff66' },
    { key: 'Gifted', color: '#ffb3ff' },
  ];

  const positions = [
    [280, 90], [480, 90],
    [280, 160], [480, 160],
    [280, 240], [480, 240],
    [280, 320], [480, 320],
  ];

  function drawBox(x, y, title, value, color) {
    const w = 160, h = 60, r = 12;
    ctx.fillStyle = 'rgba(15,15,15,0.55)';
    drawRoundedRect(ctx, x, y, w, h, r);
    ctx.fill();
    ctx.font = '18px Arial';
    ctx.fillStyle = color;
    const tw = ctx.measureText(title).width;
    ctx.fillText(title, x + (w - tw) / 2, y + 22);
    ctx.font = '20px Arial';
    ctx.fillStyle = '#fff';
    const vw = ctx.measureText(value.toString()).width;
    ctx.fillText(value.toString(), x + (w - vw) / 2, y + 45);
  }

  entries.forEach((e, i) => {
    const [x, y] = positions[i];
    drawBox(x, y, e.key, stats[e.key], e.color);
  });

  const rankX = 480, rankY = 320;
  const w = 160, h = 60, r = 12;

  ctx.fillStyle = 'rgba(15,15,15,0.55)';
  drawRoundedRect(ctx, rankX, rankY, w, h, r);
  ctx.fill();

  ctx.font = '18px Arial';
  ctx.fillStyle = '#ff0000';
  const tw = ctx.measureText('Rank').width;
  ctx.fillText('Rank', rankX + (w - tw) / 2, rankY + 22);

  ctx.font = '20px Arial';
  ctx.fillStyle = '#ffffff'
  const vw = ctx.measureText(stats.Rank).width;
  ctx.fillText(stats.Rank, rankX + (w - vw) / 2, rankY + 45);
  
  
  fs.writeFileSync('stats_card.png', canvas.toBuffer('image/png'));
  console.log('Done Making Stats Card');
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question('Input Username: ', async (name) => {
  const stats = await fetchHypixelStats(name);
  if (!stats) {
    console.error('Cannot take stats');
    rl.close();
    return;
  }
  await createStatsCard({ username: name, stats });
  rl.close();
});
